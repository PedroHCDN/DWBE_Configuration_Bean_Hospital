package com.aulas.dwbe_dto.configs;

import com.aulas.dwbe_dto.dto.*;
import com.aulas.dwbe_dto.model.Consulta;
import com.aulas.dwbe_dto.model.Medico;
import com.aulas.dwbe_dto.model.Paciente;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class HospitalConfiguration {

    @Bean("Paciente")
    public PacienteRequestDTO getPacientePadrao() {
        PacienteRequestDTO p = new PacienteRequestDTO();
        p.setNome("Paciente Padrão");
        p.setCpf("1234-5678-10");
        p.setTelefone("1111-2222");

        return p;
    }

    @Bean("Prontuario")
    public ProntuarioRequestDTO getProntuarioPadrao() {
        ProntuarioRequestDTO p = new ProntuarioRequestDTO();
        p.setAlergia("Alergia Padrão");
        p.setObservacoes("Observações Teste");
        p.setTipoSanguineo("P+");

        return p;
    }

    @Bean(name = "Consulta")
    public ConsultaRequestDTO getConsultaPadrao() {
        ConsultaRequestDTO c = new ConsultaRequestDTO();
        c.setId(1L);
        c.setDataHora(java.sql.Date.valueOf("2023-04-27"));
        c.setMotivo("Motivo padrão");
        c.setValor(10.00);

        return c;
    }

    @Bean("Medico")
    public MedicoRequestDTO getMedicoPadrao() {
        MedicoRequestDTO m = new MedicoRequestDTO();
        m.setId(1L);
        m.setNome("Medico Padrão");
        m.setEspecialidade("Especialidade Padrão");
        m.setCrm("CRM Padrão");

        return m;
    }

    @Bean("Convenio")
    public ConvenioRequestDTO getConvenioPadrao() {
        ConvenioRequestDTO c = new ConvenioRequestDTO();
        c.setId(1L);
        c.setNome("Covenio Padrão");
        c.setCnpj("CNPJ Padrão");

        return c;
    }

    @Bean("Receita")
    public ReceitaRequestDTO getReceitaPadrao() {
        ReceitaRequestDTO r = new ReceitaRequestDTO();
        r.setId(1L);
        r.setMedicamento("Medicamento Padrão");
        r.setDosagem("Dosagem Padrão");
        r.setDuracaoDias(4);

        return r;
    }
}
